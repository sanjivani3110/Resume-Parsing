export interface Resume {
    id: string;
    name: string;
    email: string;
    experience?: string;
    skills?: string[];
    summary?: string;
  }